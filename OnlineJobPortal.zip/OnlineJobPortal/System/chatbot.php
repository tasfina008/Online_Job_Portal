<?php
$msg = strtolower(trim($_POST['message']));

$qa = [
  "hi" => "Hello! How can I help you today?",
  "hello" => "Hi there! Looking for your next job?",
  "how to apply" => "Go to the job listings and click 'Apply Now' on the job you want.",
  "how to register" => "Click on the 'Register' button at the top right and fill in your details.",
  "how to login" => "Click on the 'Login' button and enter your credentials.",
  "forgot password" => "Click on 'Forgot Password' on the login page to reset it.",
  "how to search jobs" => "Use the search bar or filters to find jobs by category, location, or company.",
  "can i apply without an account" => "No, you must create an account to apply.",
  "how to upload resume" => "Go to your profile and click 'Upload Resume'.",
  "can i edit my profile" => "Yes, log in and go to your profile to edit details.",
  "how do i contact employers" => "Employers will contact you if you're shortlisted.",
  "how to check application status" => "Go to your dashboard > My Applications.",
  "what is jobkhujo" => "JobKhujo is an online job portal helping you connect with employers easily.",
  "is jobkhujo free" => "Yes, it's completely free for job seekers.",
  "how to post a job" => "Employers can log in and use 'Post Job' from the dashboard.",
  "how do i delete my account" => "Go to Settings > Delete Account.",
  "how to save jobs" => "Click the bookmark icon on a job listing to save it.",
  "can i apply to multiple jobs" => "Yes, you can apply to as many jobs as you like.",
  "do you notify about new jobs" => "Yes, if you turn on job alerts in your profile.",
  "how to set job alerts" => "Go to Settings > Notifications and enable job alerts.",
  "can i see company details" => "Yes, click the company name on the job listing.",
  "can i contact support" => "Yes, use the contact form in the footer or email support@jobkhujo.com.",
  "how to change password" => "Go to Profile > Change Password.",
  "do you verify job posts" => "Yes, we manually verify every employer and job post.",
  "are internships available" => "Yes, filter by 'Internship' in job type.",
  "do you have remote jobs" => "Yes! Use the 'Remote' filter while searching.",
  "how do i update resume" => "Go to Profile > Upload Resume and replace the file.",
  "what if i forget my username" => "Your username is your registered email address.",
  "can i deactivate my account temporarily" => "Currently, we only support permanent deletion.",
  "can i see salary info" => "Some jobs list salaries; others may not. Click the job to see details.",
  "how many jobs can i apply for" => "There's no limit!",
  "can i apply via mobile" => "Yes, JobKhujo is mobile-friendly.",
  "are there company reviews" => "Not yet, but we're working on it!",
  "can i apply without resume" => "Some jobs allow it, but having a resume helps a lot.",
  "is there an app" => "Not yet, but you can use the mobile site easily.",
  "how do i report a job scam" => "Click 'Report' on the job listing or email support.",
  "can i filter jobs by location" => "Yes, use the location filter in the search area.",
  "how long does hiring take" => "It depends on the employer — some respond quickly, some take time.",
  "will i be notified when selected" => "Yes, you'll get an email and see updates in your dashboard.",
  "can i add multiple resumes" => "Currently, only one resume is allowed at a time.",
  "what file types are supported" => "PDF, DOC, and DOCX formats.",
  "can employers call me directly" => "If you provide your phone number, yes.",
  "what if i miss a call from employer" => "Check your email and call logs, then follow up with them.",
  "how do i unsubscribe from emails" => "Click 'unsubscribe' at the bottom of the email or adjust your profile settings.",
  "how can i stand out" => "Complete your profile and upload a great resume.",
  "can i see application deadlines" => "Yes, it's listed in each job post.",
  "can i sort jobs by date" => "Yes, use the 'Sort by Date' option.",
  "can i apply if i'm a fresher" => "Absolutely! Look for jobs marked as 'Fresher-Friendly'.",
  "how do i reset my password" => "Use the 'Forgot Password' link on the login page.",
  "do i need a cover letter" => "Optional, but it can improve your chances.",
  "how do i know my application is submitted" => "You'll see a confirmation message and it will appear in your dashboard.",
  "what is the best time to apply" => "Earlier in the day gives better visibility!"
];

if ($msg === "" || $msg === "help" || $msg === "options") {
    $questions = "";
    foreach ($qa as $question => $answer) {
        $questions .= "<button class='chat-option' style='margin:4px 5px;padding:5px 10px;background:#d0e7ff;border:none;border-radius:5px;cursor:pointer;color:#000;'>".ucfirst($question)."</button><br>";
    }
    echo "Here are some things you can ask:<br>" . $questions;
} else {
    echo $qa[$msg] ?? "Sorry, I didn't understand that. Type 'help' to see what you can ask.";
}
?>
